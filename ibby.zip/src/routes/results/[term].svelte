<script>
    import ProductCard from "$lib/components/ProductCard.svelte";
    import { page } from "$app/stores";
    import { onMount } from "svelte";
    import Searchbox from "$lib/components/Searchbox.svelte";
    import { goto } from "$app/navigation";
    import LoadingWheel from "$lib/components/LoadingWheel.svelte";
    
    let products = [];
    let term = $page.params.term;

    onMount(() => {
        console.log(term);
        fetch("http://127.0.0.1:5000/search/" + term)
            .then((response) => response.json())
            .then((data) => {
                products = data.products;
                console.log(products);
            });
    });

    const search = (term) => {
        console.log(term);
        goto("/results/" + term);
    };
</script>

<div class="searchbox">
    <Searchbox {search} />
</div>

<div class="loading-wheel">
    <LoadingWheel/>
</div>

<div class="products-display">
    <div class="products-grid">
        {#each products as product}
            <ProductCard {product} />
        {/each}
    </div>
</div>

<style>
    * {
        /* outline: 1px solid green; */
    }
    .searchbox, .loading-wheel {
        align-items: center;
        display: flex;
        justify-content: center;
    }
    .products-display {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        margin-top: 5rem;
    }

    .products-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        background: gainsboro;
    }
</style>
