<script>
  import CategoryGrid from "$lib/components/Category-Grid.svelte";
  import Searchbox from "$lib/components/Searchbox.svelte";

  import { goto } from "$app/navigation";
  import BrandsGrid from "$lib/components/BrandsGrid.svelte";
  import LoginForm from "$lib/components/LoginForm.svelte";

  let products = [];

  const search = (term) => {
    console.log(term);
    goto("/results/" + term);
  };
</script>

<svelte:head>
  <script
    src="https://kit.fontawesome.com/d397854d5c.js"
    crossorigin="anonymous"></script>
</svelte:head>

<div class="wrapper-main">
  <h1>DIWHERE</h1>
  <h2>Search for products anywhere!</h2>

  <div class="searchbox">
    <Searchbox {search} />
  </div>

  <div class="category-title">
    <h1>Product Categories</h1>
  </div>

  <CategoryGrid />

  <div class="brands-title">
    <h1>Brands Categories</h1>
  </div>
  
  <BrandsGrid />

  
</div>

<style>
  .searchbox {
    align-items: center;
    display: flex;
    justify-content: center;
  }
  .wrapper-main {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding-top: 2rem;
  }

  .category-title,
  .brands-title {
    font-size: 2rem;
    margin-top: 2.5rem;
    padding-bottom: 2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 50rem;
    border-bottom: 1px solid #abaca6;
  }
</style>
