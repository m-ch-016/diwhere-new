<script>
  import HeaderButton from "./HeaderButton.svelte";
  import Navbar from "./Navbar.svelte";

  import { createEventDispatcher } from "svelte";

  const dispatch = createEventDispatcher();
  const loginclicked = () => {
    console.log("bababa");
    dispatch("login");
  };
</script>

<header>
  <a href="/" class="logo"><h1>DIWhere</h1></a>
  <Navbar />
  <HeaderButton on:click={loginclicked}>Login/Register</HeaderButton>
</header>

<style>
  header {
    display: flex;
    justify-content: space-between;
    padding: 1.5rem;
    align-items: center;
    color: hsl(48, 100%, 50%);
    background-color: hsl(185, 96%, 19%);
  }

  .logo {
    font-size: 3rem;
    font-weight: 700;
  }

  a {
    color: inherit;
    text-decoration: none;
  }
</style>
