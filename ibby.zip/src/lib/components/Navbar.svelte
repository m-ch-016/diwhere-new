<script>
    import Navlink from "./Navlink.svelte";
</script>

<nav>
    <Navlink link="/">Home</Navlink>
    <Navlink link="/">Brands</Navlink>
    <Navlink link="/">Settings</Navlink>
    <Navlink link="/">Trending</Navlink>
    <Navlink link="/">Chat</Navlink>
</nav>

<style>
    nav {
        display: flex;
        gap: 1rem;
    }
    Navlink {
        border-left: 1px solid black;
        color: white;
        border-left: 1px solid black;
    }
    Navlink:last-child {
        border-right: 1px solid black;
    }
    
</style>
