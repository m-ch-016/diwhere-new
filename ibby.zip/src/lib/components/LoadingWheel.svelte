<div class="loader">
    <span />
    <span />
    <span />
    <span />
    <h3>Loading...</h3>
</div>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    .loader {
        position: relative;
        width: 200px;
        height: 200px;
        background: #1a1a1f;
        color: #ffcb00;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: 0.5s;
        overflow: hidden;
    }

    .loader:hover {
        background: #ffcb00;
        color: #050801;
        box-shadow: 0 0 5px #ffcb00,
        0 0 25px #ffcb00,
        0 0 50px #ffcb00,
        0 0 200px #ffcb00;
    }

    .loader span {
        position: absolute;
        display: block;
    }

    .loader span:nth-child(1) {
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(90deg, transparent, #ffcb00);
        animation: animate1 2s linear infinite;
        animation-delay: 0s;
    }

    @keyframes animate1 {
        0% {
            left: -100%;
        }

        50%, 100% {
            left: 100%;
        }
    }
    .loader span:nth-child(3) {
        bottom: 0;
        right: -100%;
        width: 100%;
        height: 5px;
        background: linear-gradient(270deg, transparent, #ffcb00);
        animation: animate3 2s linear infinite;
        animation-delay: 1.5s;
    }

    @keyframes animate3 {
        0% {
            right: -100%;
        }

        50%, 100% {
            right: 100%;
        }
    }
    .loader span:nth-child(2) {
        top: -100%;
        right: 0;
        height: 100%;
        width: 5px;
        background: linear-gradient(180deg, transparent, #ffcb00);
        animation: animate2 2s linear infinite;
        animation-delay: 1s;
    }

    @keyframes animate2 {
        0% {
            top: -100%;
        }

        50%, 100% {
            top: 100%;
        }
    }
    
    .loader span:nth-child(4) {
        bottom: -100%;
        left: 0;
        height: 100%;
        width: 5px;
        background: linear-gradient(360deg, transparent, #ffcb00);
        animation: animate4 2s linear infinite;
        animation-delay: 2s;
    }

    @keyframes animate4 {
        0% {
            bottom: -100%;
        }

        50%, 100% {
           bottom : 100%;
        }
    }
</style>
