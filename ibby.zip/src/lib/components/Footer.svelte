<script>
  import Social from "./Social.svelte";
</script>

<footer>

    <div class="categories">
      <h3>Categories</h3>
      <div class="categories-all">
        <p>Bathroom</p>
        <p>Building</p>
        <p>Electrics</p>
        <p>Furniture</p>
        <p>Heating</p>
        <p>Kitchen</p>
        <p>Outdoor</p>
        <p>Paint</p>
        <p>Plumbing</p>
        <p>Tiling</p>
        <p>Timber</p>
        <p>Tools</p>
      </div>
    </div>
    <div class="contact">
      <div class="socials">
        <ul>
          <li><Social link="/" icon="fa-instagram" /></li>
          <li><Social link="/" icon="fa-twitter" /></li>
          <li><Social link="/" icon="fa-tiktok" /></li>
          <li><Social link="/" icon="fa-facebook-f" /></li>
        </ul>
      </div>
      <div class="info">
        <h3>Contact</h3>
        <div class="contact-methods">
          <p>Contact us via email</p>
          <p>Contact us via phone</p>

          <div class="address">
            <p>Head Office: 3-9 Hyde Road, Manchester, M12 6BQ</p>
          </div>
        </div>
      </div>
    </div>
    <div class="details">
      <h3>Details</h3>
      <p>About Us</p>
      <p>Privacy & Cookie Statement</p>
      <p>Terms & Conditions</p>

      <br />
      <h4>Copyright</h4>
      <p>© Muhammed Choudhary</p>
    </div>
</footer>

<style>
  .socials {
    margin-top: 1rem;
    position: relative;
    width: 23.2rem;
    margin-bottom: 2rem;
    height: 10vh;
    margin-left: 2rem;
    margin-right: 2rem;
    justify-content: space-around;
    display: flex;
    /* justify-content: center; */
    align-items: center;
    background: linear-gradient(to bottom, #02585f, #02585f);
  }

  .socials::before {
    content: "";
    position: absolute;
    bottom: 0;
    width: 23.2rem;
    height: 5vh;
    z-index: 1;
    backdrop-filter: blur(5px);
  }

  .socials ul {
    position: relative;
    display: flex;
    z-index: 2;
  }

  .socials ul li {
    position: relative;
    list-style: none;
    margin-right: 10px;
  }

  footer {
    display: flex;
    padding: 2rem;
    justify-content: space-between;
    background-color: #02585f;
    color: #ffcb00;
  }

  .categories-all {
    display: flex;
    flex-direction: column;
    gap: 0.1rem;
  }
  
  .categories h3 {
    margin-bottom: 1rem;
  }

  .info {
    width: 30rem;
    padding-top: 1rem;
    border-top: 1px solid #b6bbc3;
  }
  .info h3 {
    text-align: center;
    margin-bottom: 1rem;
  }

  .address {
    margin-top: 2rem;
  }

  .details h3 {
    margin-bottom: 1rem;
  }
</style>
