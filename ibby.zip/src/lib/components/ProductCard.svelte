<script>
    export let product;
</script>

<a href={product[2]}>
    <div class="product-card">
        <div class="content">
            <div class="product-top">
                <img src={product[3]} alt="" />
                <h1>{product[1]}</h1>
            </div>
            
            <div class="product-title">
                {product[0]}
            </div>
            
            <div class="product-src">
                {product[4]}    
            </div>

            <!-- <a href={product[2]}> -->
                <div href={product[2]} class="product-link">
                    Take me to the website
                </div>
            <!-- </a> -->
                <!-- get bnq image in bottom corner -->
            
        </div>
    </div>
</a>

<style>
    * {
        /* outline: 1px solid green; */
    }
    p,
    h1,
    h2,
    h3 {
        color: black;
    }
    /* .product-card {
        display: flex;
        margin-top: 3rem;
        margin-left: 3rem;
        margin-right: 3rem;
        margin-bottom: 3rem; 
        position: relative;
        width: 400px;
        height: 400px;
        border-radius: 20px;
        display: flex;
        align-items: center;
        border-radius: 20px;
        transition: 0.5s;
        padding: 0;
    } */

    .product-card {
        width: 400px;
        height: 400px;
        margin-right: 2px;
        margin-left: 2px;
        margin-bottom: 2px;
        margin-top: 2px;

        /* border-color: ; */
        background-color: white;
        position: relative;
    }

    .product-top {
        display: flex;
        flex-direction: column;
    }
    
    .product-top h1 {
        margin-top: 50%;
        text-align: right;
        display: flex;
        padding-right: 2px;
        padding-left: 2px;
        align-items: flex-end;
        color: black;
    }

    
    
    .product-card .content {
        display: flex;
        flex-direction: column;
        position: relative;
    }

    .product-title {
        margin-top: 1rem;
        margin-bottom: 2rem;
        color: grey;
        font-size: 1.1rem;
        font-weight: 200;
    }

    .product-src {
        position: relative;
        display: flex;
        bottom: 0;
        left: 0;
    }

    .product-card img {
        width: 50%;
        height: 50%;
        position: absolute;
        top: 0%;
        left: 25%;
    }

    .product-link {
        text-decoration: none;
        width: 50%;
        margin-left: 25%;
        margin-right: 25%;
        padding: 0.5rem 0.5rem;
        border-radius: 1rem;
        align-items: center;
        justify-content: center;
        display: flex;
        background-color: gainsboro;
    }

    .product-link::after {
        content: "";
        height: 0;
        width: 100%;
        position: absolute;
        left: 0;
        bottom: 0;
        background-color: #ffcb00;
        z-index: -1;
        /* transition: 0.5s; */
    }

    .product-link:hover {
        background-color: #ffcb00;
        transition: 0.5s;
    }

    .product-link:hover::after {
        height: 100%;
    }
    /* .product-card .circle {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 30px;
        overflow: hidden;
    }

    .product-card .circle::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #02585f;
        clip-path: circle(80px at center);
        transition: 0.5s;
    }

    .product-card:hover .circle::before {
        clip-path: circle(400px at center);
        background: #ffcb00;
    }

    .product-card img {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        height: 100px;
        pointer-events: none;
        transition: 0.5s;
    }

    .product-card:hover img {
        left: 80%;
        height: 275px;
    }

    .product-card:hover::after {
        border-radius: 20px;
    }

    .product-card .content {
        position: relative;
        width: 50%;
        padding: 10px 10px 10px 20px;
        transition: 0.5s;
        opacity: 0;
        visibility: hidden;
    }

    .product-card:hover .content {
        left: 0;
        opacity: 1;
        visibility: visible;
    }

    .product-card .content h2 {
        text-transform: uppercase;
        font-size: 2em;
        line-height: 1em;
        padding-bottom: 2.5rem;
    }

    .product-card .content p {
        transform: translateY(-30px);
    } */
</style>
