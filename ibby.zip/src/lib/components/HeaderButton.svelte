<script>

</script>

<button>
    <slot />
</button>

<style>
    button {
        color: inherit;
        text-decoration: none;
        position: relative;
        z-index: 0;
        font-size: 1.5rem;
        padding: 0.5rem 2rem;
        transition: color 0.5s;
        border-radius: 1rem;
        overflow: hidden;
        box-shadow: 0 0 black;
    }

    button::after {
        content: "";
        height: 0;
        width: 100%;
        position: absolute;
        left: 0;
        bottom: 0;
        background-color: #ffcb00;
        z-index: -1;
        transition: 0.5s;
    }

    button:hover {
        font-weight: 600;
        box-shadow: 0px 2px black;
        color: black;
    }

    button:hover::after {
        height: 100%;
    }
</style>
